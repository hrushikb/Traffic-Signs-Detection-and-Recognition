clear all
close all
%getting the file from the system and saving its path and name in 'image'.
[FileName, path] = uigetfile('*.*', 'Specify an image file');
image = fullfile(path, FileName);

% reads the indexed image and reads its associated colormap into map
[rgbImage map] = imread(image);
[rows columns numberOfColorBands] = size(rgbImage);

%% isolating all the 3 colours 
redBand = rgbImage(:, :, 1);
greenBand = rgbImage(:, :, 2);
blueBand = rgbImage(:, :, 3);

[redObjectsMask,maskedRGBImage] = createMask(rgbImage);

redObjectsMask= uint8(redObjectsMask);
subplot(2,3,1);
%to get max and min values of redObjectsMask,i.e white and black
imshow(redObjectsMask, []);
title('The Red Objects');

%% keeping area larger than 100 pix

Area = 100;

%bwareaopen(BW,P) removes all connected components that have fewer than P pixels from the binary image BW, producing another binary image

redObjectsMask = uint8(bwareaopen(redObjectsMask, Area));
subplot(2, 3, 2);
imshow(redObjectsMask, []);
title('removed smaller objects');


%% Smooth the border using imclose().
%strel('disk',r) creates a disk-shaped structuring element, where r specifies the radius
sign = strel('disk', 4);
%imclose(I,SE) performs morphological closing on the grayscale or binary image, returning the closed image
redObjectsMask = imclose(redObjectsMask, sign);
 subplot(2, 3,3);
imshow(redObjectsMask, []);
title('closed/smoothned border');

%% Filling the closed regions, since they are most likely to be traffic signs.
redObjectsMask =imfill(redObjectsMask, 'holes');
subplot(2, 3, 4);
imshow(redObjectsMask, []);
title('Regions Filled');

%% displaying the traffic sign 
% You can only multiply integers if they are of the same type.
% We need to convert the type of redObjectsMask to the same data type as redBand.

%cast(A,newclass) converts A to the data type (class) newclass, where newclass is the name of a built-in data type compatible with A.
%The cast function truncates any values in A that are outside the range of newclass to the nearest endpoint.

redObjectsMask = cast(redObjectsMask, class(redBand));

maskedImageR = redObjectsMask .* redBand;
maskedImageG = redObjectsMask .* greenBand;
maskedImageB = redObjectsMask .* blueBand;
%cat(dim,A,B) concatenates B to the end of A along dimension dim when A and B have compatible sizes
maskedRGBImage = cat(3, maskedImageR, maskedImageG, maskedImageB);
subplot(2, 3, 5);
imshow(maskedRGBImage);
title('sign');

%%  Obtain the boundaries of all the signs in the binary image.

bw=imbinarize(redObjectsMask);
%bwboundaries(BW) traces the exterior boundaries of objects and return the matrix L.
%N is no of objects found
%B is the output matrix consists co-ordinates of exterior boundaries (it is 2-dimensional)

[B,L,N]= bwboundaries(bw,'holes');

%stats = regionprops(L,properties) measures a set of properties for each labeled region in label image L

blobs = regionprops(L, 'Centroid', 'Area', 'Perimeter','Circularity', 'Image');
Perimeter = cat(1,blobs.Perimeter);
Area = cat(1,blobs.Area);

numofSides = FindNumberOfVertices(blobs, L);

CircleMetric = (4*pi*Area)./(Perimeter.^2);  %circularity metric

%% Plot the boundary for one of the sign over the original image.

figure;
imshow(rgbImage)
title('detected sign');
hold on;
dividingValues = PlotTheoreticalCircularity;


for k=1:length(B)
    boundary = B{k};
    stats=  blobs(k);
    
    
    
    
    plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 2)

    % Use |reducepoly| to reduce the number of points defining the coin boundary.
    p = [boundary(:,2) boundary(:,1)];
    tolerance = 0.08; % choose suitable tolerance
    p_reduced = reducepoly(p,tolerance);
    % p_reduced = unique(p_reduced,'row')
    plot(p_reduced(:,1),p_reduced(:,2),...
        'color',[0 0 1],'linestyle','-','linewidth',2,...
        'marker','o','markersize',5)
    
    thisBlob = stats.Image;
    allBwAreas = bwarea(thisBlob);
    allPerimeters = stats.Perimeter;
    bwCircularities = (4 * pi *  allBwAreas) ./ allPerimeters.^2
    %==============================================================
    % Determine the number of sizes according to the circularity
    % Get the circularity of this specific blob.
    thisCircularity = bwCircularities %sortedCircularities(blobNumber);
    % See which theoretical dividing value it's less than.
    % This will determine the number of sides it has.
    numSidesCircularity = find(thisCircularity < dividingValues, 1, 'first');
    % Assign a string naming the shape according to the distance algorithm.
    if numSidesCircularity == 3
        % Blob has 3 sides.
        theShapeCirc = 'triangle';
    elseif numSidesCircularity == 4
        % Blob has 4 sides.
        theShapeCirc = 'square';
    elseif numSidesCircularity == 5
        % Blob has 5 sides.
        theShapeCirc = 'pentagon';
    elseif numSidesCircularity == 6
        % Blob has 6 sides.
        theShapeCirc = 'hexagon';
    else
        % Blob has 7 or more sides.
        theShapeCirc = 'nearly circular';
    end
    
    %==============================================================
    % Determine the number of sizes according to the centroid-to-perimeter algorithm
    NumSides = numofSides(k);
    % Assign a string naming the shape according to the distance algorithm.
    if NumSides == 3
        % Blob has 3 sides.
        theShapeDistance = 'triangle';
    elseif NumSides == 4
        % Blob has 4 sides.
        theShapeDistance = 'square';
    elseif NumSides == 5
        % Blob has 5 sides.
        theShapeDistance = 'pentagon';
    elseif NumSides == 6
        % Blob has 6 sides.
        theShapeDistance = 'hexagon';
        
   % elseif NumSides>9
        % Blob has 7 or more sides.
       % theShapeDistance = 'nearly circular';
    else
        theShapeDistance = 'nearly circular';
        
    end
    
    poly = polyshape(p_reduced)
    Peri = perimeter(poly);
    Area_l = polyarea(p_reduced(:,1),p_reduced(:,2));
    
    if NumSides>=3 || (CircleMetric(k) < 1)
        
        
        pos=[ min(p(:,1)),min(p(:,2)), abs(max(p(:,1))- min(p(:,1))),abs(max(p(:,2))-min(p(:,2)))];
        rectangle('Position',pos,'EdgeColor','r','LineWidth',3)

        text(pos(1)+10,pos(2)+pos(4)+20, theShapeDistance,'Color','red','FontSize',14);
    end
 
end
%% extract the sign from the image

rgbImage=rgbImage(min(p(:,2)):max(p(:,2)),min(p(:,1)):max(p(:,1)));
figure
subplot(1,2,1);
imshow(rgbImage)
title('extracted sign(grey scale image)');
Img=imbinarize(rgbImage);
subplot(1,2,2);
imshow(Img);
title('extracted sign(black and white image)');
%%
function [BW,maskedRGBImage] = createMask(RGB)
%createMask  Threshold RGB image using auto-generated code from colorThresholder app.
%  [BW,MASKEDRGBIMAGE] = createMask(RGB) thresholds image RGB using
%  auto-generated code from the colorThresholder app. The colorspace and range for each channel of the colorspace were set within the app.
%  original RGB images is returned in maskedRGBImage.

% Convert RGB image to chosen color space
I = rgb2hsv(RGB);

% Define thresholds for channel 1 based on histogram settings
channel1Min_red = 0.900;
channel1Max_red = 0.051;

% Define thresholds for channel 2 based on histogram settings
channel2Min = 0.590 
channel2Max = 1.000;

% Define thresholds for channel 3 based on histogram settings
channel3Min = 0.49;
channel3Max = 1.000;

% Create mask based on chosen histogram thresholds
sliderBW =  ((I(:,:,1) >= channel1Min_red) | (I(:,:,1) <= channel1Max_red))  & ...
    (I(:,:,2) >= channel2Min ) & (I(:,:,2) <= channel2Max) & ...
    (I(:,:,3) >= channel3Min ) & (I(:,:,3) <= channel3Max);
BW = sliderBW;

% Initialize output masked image based on input image.
maskedRGBImage = RGB;

% Set background pixels where BW is false to zero.
maskedRGBImage(repmat(~BW,[1 1 3])) = 0;

end
%%
function dividingValues = PlotTheoreticalCircularity()
    dividingValues = [];
    % For reference, compute the theoretical circularity of a bunch of regular polygons with different number of sides.
    numSides = 3 : 16;
    for k = 1 : length(numSides)
        thisSideLength = numSides(k);
        circularity(k) = ComputeTheoreticalCircularity(thisSideLength);
    end
    
    % Get the midpoint between one circularity and the one for the next higher number of sides.
    dividingValues = conv(circularity, [1, 1]/2, 'valid');
    % For example, right now dividingValues(1) gives us the dividing value between 3 and 4
    % and dividingValues(3) gives us the dividing value between 5 and 6 (instead of between 3 and 4).
    dividingValues = [0, 0, dividingValues];
end
%%
% https://en.wikipedia.org/wiki/Regular_polygon
% Which says A = (1/4) * n * s^2 * tan(pi/n)
function circularity = ComputeTheoreticalCircularity(numSides)
    sideLength = 1;
    perimeter = numSides * sideLength;
    area = (1/4) * numSides * sideLength^2 / tan(pi / numSides);
    circularity = (4 * pi * area) / perimeter ^2;
end


%%
% Now compute the number of vertices by looking at the number of peaks in a plot of distance from centroid.
function numVertices = FindNumberOfVertices(Measurements, labeledImage)
    numVertices = 0;
    % Get the number of blobs in the image.
    numRegions = length(Measurements);
    hFig = figure;
    promptUser = true; 
    
    % For each blob, get its boundaries and find the distance from the centroid to each boundary point.
    for k = 1 : numRegions
        % Extract just this blob alone.
        thisBlob = ismember(labeledImage, k) > 0;

        thisBoundary = bwboundaries(thisBlob);
        thisBoundary = cell2mat(thisBoundary); % Convert from cell to double.
        % Get x and y
        x = thisBoundary(:, 2);
        y = thisBoundary(:, 1);
        % Get the centroid
        xCenter = Measurements(k).Centroid(1);
        yCenter = Measurements(k).Centroid(2);
        % Compute distances
        distances = sqrt((x - xCenter).^2 + (y - yCenter).^2);
 
       
        % Find the range of the peaks
        peakRange = max(distances) - min(distances);
        minPeakHeight = 0.5 * peakRange;
        % Find the peaks
        
        [peakValues, peakIndexes] = findpeaks(distances, 'MinPeakProminence', minPeakHeight);
        % Find the valueys.
        [valleyValues, valleyIndexes] = findpeaks(-distances, 'MinPeakProminence', minPeakHeight);
        numVertices(k) = max([length(peakValues), length(valleyValues)]);
 
        if numVertices(k) > 10
            numVertices(k) = 0;
        end
    end
    close(hFig);
end