clear all
close all
%getting the file from the system and saving its path and name in 'image'.
[FileName, path] = uigetfile('*.*', 'Specify an image file');
image = fullfile(path, FileName);
% reads the indexed image and reads its associated colormap into map
[im map] = imread(image);

%% load all traffic signs

im1 = imread('stop.jpeg');
im2 = imread('pedestrians prohibited.jpeg');
im3 = imread('speed bumps ahead.jpeg');
im4 = imread('truck prohibited.jpeg');
im5 = imread('horn prohibited.jpeg');
im6 = imread('uturn prohibited.jpeg');
im7 = imread('no entry.jpeg');
im8 = imread('turn right prohibited.jpeg');
im9 = imread('turn left prohibited.jpeg');
im10 = imread('overtaking prohibited.jpeg');
im11 = imread('speed limit.jpeg');
im12 = imread('vehicles prohibited in both directions.jpeg');
im13= imread('narrow bridge ahead.jpeg');
im14= imread('turn right.jpeg');
im15= imread('turn left.jpeg');
im16= imread('children crossing.jpeg');
im17= imread('pedestrian crossing sign.jpeg');
im18= imread('two ways traffic.jpeg');
im19= imread('no parking.jpeg');

%% comparing the input signs with are traffic signs , 
% correlation is tool that computes the similarities between two matrix

m1=correlation(im,im1);
m2=correlation(im,im2);
m3=correlation(im,im3);
m4=correlation(im,im4);
m5=correlation(im,im5);
m6=correlation(im,im6);
m7=correlation(im,im7);
m8=correlation(im,im8);
m9=correlation(im,im9);
m10=correlation(im,im10);
m11=correlation(im,im11);
m12=correlation(im,im12);
m13=correlation(im,im13);
m14=correlation(im,im14);
m15=correlation(im,im15);
m16=correlation(im,im16);
m17=correlation(im,im17);
m18=correlation(im,im18);
m19=correlation(im,im19);

% if correlation is max then both the matrices are identical

A = [max(m1) max(m2) max(m3) max(m4) max(m5) max(m6) max(m7) max(m8) max(m9) max(m10) max(m11) max(m12) max(m13) max(m14) max(m15) max(m16) max(m17) max(m18) max(m19)];
M = max(A);
if(max(m1)==M)
    imshow(im)
    title({'stop','(indicates to stop the vehicle)'});
elseif(max(m2)==M)
    imshow(im);
    title({'pedestrians prohibited','(restricts the movement of pedestrian on road)'});
elseif(max(m3)==M)
    imshow(im);
    title({'speed bumps ahead','(warns you that there is a bump up ahead on the road)'});
elseif(max(m4)==M)
    imshow(im);
    title({'truck prohibited','(sign itself speaks the area designated is a no entry zone for Trucks or HMV)'});
elseif(max(m5)==M)
    imshow(im);
    title({'horn prohibited','(sign directs driver to respect the silence zone and not to use horn)'});
elseif(max(m6)==M)
    imshow(im);
    title({'uturn prohibited','(taking a U-turn where this sign is placed is prohibited)'});
elseif(max(m7)==M)
    imshow(im);
    title({'no entry','(No Entry is used on signs to indicate that you are not allowed to go into a particular area)'});
elseif(max(m8)==M)
    imshow(im);
    title({'turn right prohibited','(This sign directs the traffic to either move straight or take left turn. Turning towards right is prohibited)'});
elseif(max(m9)==M)
    imshow(im);
    title({'turn left prohibited','(This sign directs the traffic to either move straight or take right turn. Turning towards left is prohibited)'});
elseif(max(m10)==M)
    imshow(im);
    title({'overtaking prohibited','(sign directs us not to overtake any vehicles infront of you)'});
elseif(max(m11)==M)
    imshow(im);
    title({'speed limit','( Speed limit signs tell you the legal allowable limits.)'});
elseif(max(m12)==M)
    imshow(im);
    title({'vehicles prohibited in both directions','(This indicates that the traffic flow is allowed in only one direction)'});
elseif(max(m13)==M)
    imshow(im);
    title({'narrow bridge ahead','(This sign indicates that there is a narrow bridge approaching and the driver needs to slow down and watch out for oncoming vehicles)'});
elseif(max(m14)==M)
    imshow(im);
    title({'turn right','(This sign directs the traffic to either move straight or take right turn)'});
elseif(max(m15)==M)
    imshow(im);
    title({'turn left','(This sign directs the traffic to either move straight or take left turn)'});
elseif(max(m16)==M)
    imshow(im);
    title({'children crossing','(These signs are used to communicate to the driver to come to a stop in case kids are about to cross a road)'});
elseif(max(m17)==M)
    imshow(im);
    title({'pedestrian crossing sign','(This sign cautions the driver to either slow down or stop the vehicle and allow the pedestrian to cross the road)'});
elseif(max(m18)==M)
    imshow(im);
    title({'two ways traffic','(signs indicate us that you are leaving a separated one-way roadway and entering a two-way roadway)'});
elseif(max(m19)==M)
    imshow(im);
    title({'no parking','(this sign is used where parking is prohibited)'});
end  


%% function to compute correlation
 
function [corr]= correlation(ref,image)
A = rgb2gray(ref);

% imbinarize(A) converts the image to black and white i.e white is 1 and
% black is 0

A1 = imbinarize(A);
% making both images to same dimensions, to perform correlation
A2=imresize(A1, [500,500]);

B = rgb2gray(image);
B1 = imbinarize(B);
B2=imresize(B1, [500,500]);

%to calculate similarity between ref and new image
corr = corr2(A2,B2); 
end